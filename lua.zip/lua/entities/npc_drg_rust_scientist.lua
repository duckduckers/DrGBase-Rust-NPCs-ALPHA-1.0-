if not DrGBase then return end -- return if DrGBase isn't installed
ENT.Base = "drgbase_nextbot_human" -- DO NOT TOUCH (obviously)

-- Misc --
ENT.PrintName = "Scientist"
ENT.Category = "[DrGBase] Rust"
ENT.Models = {"models/player/darky_m/rust/scientist.mdl"}
ENT.Skins = {0}

-- Relationships --
ENT.Factions = {FACTION_SCIENTIST}

-- Movements --
ENT.UseWalkframes = true

-- Weapons --
ENT.Weapons = {
  "weapon_drg_rust_scientist_geiger",
}
ENT.WeaponAccuracy = 0.75


if SERVER then

  -- Init/Think --

  function ENT:CustomInitialize()
    self:SetDefaultRelationship(D_HT)
    self:SetSelfModelRelationship(D_LI)
    if self:GetModel() == "models/player/darky_m/rust/scientist.mdl" then
      self:JoinFaction("FACTION_SCIENTIST")
    elseif self:GetModel() == "models/player/darky_m/rust/scientist.mdl" then
      self:JoinFaction("FACTION_SCIENTIST")
    end
  end

end

-- DO NOT TOUCH --
AddCSLuaFile()
DrGBase.AddNextbot(ENT)
