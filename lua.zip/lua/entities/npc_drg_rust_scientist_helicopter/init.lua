AddCSLuaFile( "cl_init.lua" )
AddCSLuaFile( "shared.lua" )
include('shared.lua')

ENT.Alerted     		= false
ENT.AlertedCurTime		= 0
ENT.AlertedCurTimeEnd	= -1
ENT.Patrol				= true
ENT.PatrolPoint			= nil
ENT.FailStep 			= -1
ENT.FailStepUsed		= {}
ENT.FailCurTime			= 0
ENT.StartHealth 		= 650
ENT.PequodDown			= false
ENT.State 				= 0 
ENT.Enemy 				= NULL
ENT.EnemyIsVehicle		= false
ENT.dead 				= false
ENT.DestAlt 			= 0
ENT.rocket_toggle 		= false
ENT.cooldownCheck 		= false
ENT.cooldown 			= false
ENT.cooldownTime     	= 3
ENT.shootTime			= 10
ENT.EnabledFire			= true
ENT.RemoveTimeProps		= 30   
ENT.Smoke				= false
ENT.maxDistance			= 1500
ENT.minDistance 		= 500
ENT.FindEnemyRadius		= 7000
ENT.Tilt = false
ENT.ConstTarget = NULL
ENT.ConstOnly = false
ENT.RocketLock = false
ENT.NPCWhiteList 		= {
	"npc_drg_rust_scientist",
	"npc_drg_rust_outpost_scientist",
}
ENT.PlyWhiteSteamID 	= {
	-- "STEAM_0:0:0"
}
ENT.PlyWhiteUserGroup 	= {
	-- "owner",
	-- "superadmin",
	-- "admin",
}
ENT.PlyWhiteTeam 		= {
	TEAM_SCI,
	TEAM_GUARD,
}

function ENT:Initialize()
	self:SetModel( "models/kali/vehicles/ghosts/aircraft/nh-90.mdl" )		
	self.Entity:PhysicsInit( SOLID_VPHYSICS )   
	self.Entity:SetMoveType( MOVETYPE_VPHYSICS )   	
	self.Entity:SetSolid( SOLID_VPHYSICS )  
	self:CapabilitiesAdd( CAP_MOVE_FLY )
	self:SetPos(self:GetPos() + Vector(0, 0, 150))

	self:SetHealth(self.StartHealth)
	self.Enemy = NULL
	self.LoopSound = CreateSound(self, Sound("npc/attack_helicopter/aheli_rotor_loop1.wav"))
	self.warningSound = CreateSound(self, Sound("apache/lowhealth.mp3"))
	self.pequod_down_sound = CreateSound(self, Sound("pequod_down_sound"))

	self.LoopSound:PlayEx(500,100)
	self.DestAlt = self:GetPos().z + 500
	local phys = self.Entity:GetPhysicsObject()  	
	if (phys:IsValid()) then 		
		phys:Wake()  
		phys:EnableGravity(false) 
	end 
end
   
function ENT:OnTakeDamage(dmg)
	if self.dead then return end

	local attacker = dmg:GetAttacker()

	if dmg:IsBulletDamage() then 
		local class = attacker:GetClass()
		if (class ~= "npc_drg_rust_helicopter" and class ~= "npc_drg_rust_helicopter_friend" and class ~= "npc_combinegunship" and class ~= "npc_helicopter" and class ~= "npc_strider") then
			return
		else
			self:SetHealth(self:Health() - dmg:GetDamage()/4)
		end
	else
		self:SetHealth(self:Health() - dmg:GetDamage())
	end

	if (self.PequodDown) then
		self:BreakableCopter()
		return
	end

	if attacker:GetClass() ~= self:GetClass() and math.random(0, 100) <= 90 and (dmg:IsExplosionDamage() or dmg:GetDamageType() == DMG_BURN) then
		self.Alerted = true
		if (attacker:IsPlayer() and GetConVarNumber("ai_ignoreplayers") == 0) then
			self.Enemy = attacker
		elseif (not attacker:IsPlayer()) then
			self.Enemy = attacker
		end
	end

	if (self:Health() <= self.StartHealth/2) then
		if not self.Smoke then
			self.Smoke = self:CreateSmoke()
		end
		if not self.warningSound:IsPlaying() then
			self.warningSound:PlayEx(1,100)
		end
	end
	
	if self:Health() <= 0 and not self.dead then 
		self:KilledDan(attacker)
	end
end

function ENT:FailMove()
	local phy = self:GetPhysicsObject()
	if phy:IsValid() then
		local forward1 = self.Entity:GetAngles():Forward() * 150
		local forward2 = self.Entity:GetAngles():Forward() * 550
		local startpos = self.Entity:GetPos() + forward1 - Vector(0, 0, 100)
		local endpos = self.Entity:GetPos() + forward2 - Vector(0, 0, -30)
		local checkIsWorld = util.TraceLine( {
			start = startpos,
			endpos = endpos,
			filter = function( ent ) 
				if ( ent:GetClass() ~= "npc_drg_rust_helicopter" ) then 
					return true
				end 
			end
		} )

		local ceiling = util.TraceLine( {
			start = self.Entity:GetPos() + Vector(0, 0, 200),
			endpos = self.Entity:GetPos() + Vector(0, 0, 500),
			filter = function( ent ) 
				if ( ent:GetClass() ~= "npc_drg_rust_helicopter" ) then 
					return true
				end 
			end
		} )

		if (ceiling.Entity ~= NULL) then
			phy:AddVelocity(self.Entity:GetAngles():Up() * -40)
		end

		if (checkIsWorld.Entity ~= NULL and checkIsWorld.Entity:GetClass() == "worldspawn") then
			-- phy:AddVelocity(self.Entity:GetAngles():Forward() * -math.abs( (phy:GetVelocity().x)*(phy:GetVelocity().y)/250 ))
			phy:AddVelocity(self.Entity:GetAngles():Forward() * -50)
			local right_right_1 = self.Entity:GetAngles():Right() * 150
			local right_right_2 = self.Entity:GetAngles():Right() * 1000
			local right_check = util.TraceLine( {
				start = self.Entity:GetPos() + right_right_1 - Vector(0, 0, 100),
				endpos = self.Entity:GetPos() + right_right_2 - Vector(0, 0, 100),
				filter = function( ent ) 
					if ( ent:GetClass() ~= "npc_drg_rust_helicopter" ) then 
						return true
					end 
				end
			} )
		
			local right_left_1 = self.Entity:GetAngles():Right() * -150
			local right_left_2 = self.Entity:GetAngles():Right() * -1000
			local left_check = util.TraceLine( {
				start = self.Entity:GetPos() + right_left_1 - Vector(0, 0, 100),
				endpos = self.Entity:GetPos() + right_left_2 - Vector(0, 0, 100),
				filter = function( ent ) 
					if ( ent:GetClass() ~= "npc_drg_rust_helicopter" ) then 
						return true
					end 
				end
			} )

			if (right_check.Entity == NULL and self.FailCurTime < CurTime() and not table.HasValue(self.FailStepUsed, 1)) then
				self.FailStep = 1
				self.FailCurTime = CurTime() + 4
				table.insert(self.FailStepUsed, 1)
			elseif (left_check.Entity == NULL and self.FailCurTime < CurTime() and not table.HasValue(self.FailStepUsed, 2)) then
				self.FailStep = 2
				self.FailCurTime = CurTime() + 4
				table.insert(self.FailStepUsed, 2)
			elseif (self.FailCurTime < CurTime() and not table.HasValue(self.FailStepUsed, 3)) then
				self.FailStep = 3
				self.FailCurTime = CurTime() + 4
				table.insert(self.FailStepUsed, 3)
			end
		elseif (checkIsWorld.Entity == NULL and self.FailCurTime < CurTime() and self.FailStep ~= -1) then
			self.FailStep = -1
			table.Empty(self.FailStepUsed)
		else
			local right_right_1 = self.Entity:GetAngles():Right() * 150
			local right_right_2 = self.Entity:GetAngles():Right() * 350
			local right_check = util.TraceLine( {
				start = self.Entity:GetPos() + right_right_1 - Vector(0, 0, 100),
				endpos = self.Entity:GetPos() + right_right_2 - Vector(0, 0, 100),
				filter = function( ent ) 
					if ( ent:GetClass() ~= "npc_drg_rust_helicopter" ) then 
						return true
					end 
				end
			} )
		
			local right_left_1 = self.Entity:GetAngles():Right() * -150
			local right_left_2 = self.Entity:GetAngles():Right() * -350
			local left_check = util.TraceLine( {
				start = self.Entity:GetPos() + right_left_1 - Vector(0, 0, 100),
				endpos = self.Entity:GetPos() + right_left_2 - Vector(0, 0, 100),
				filter = function( ent ) 
					if ( ent:GetClass() ~= "npc_drg_rust_helicopter" ) then 
						return true
					end 
				end
			} )

			if (right_check.Entity ~= NULL) then
				phy:AddVelocity(self.Entity:GetAngles():Right() * -50)
			elseif (left_check.Entity ~= NULL) then
				phy:AddVelocity(self.Entity:GetAngles():Right() * 50)
			end
		end
	end

	if (self.FailStep == 1) then
		phy:AddVelocity(self.Entity:GetAngles():Right() * 40)
	elseif (self.FailStep == 2) then
		phy:AddVelocity(self.Entity:GetAngles():Right() * -40)
	elseif (self.FailStep == 3) then
		phy:AddVelocity(self.Entity:GetAngles():Up() * 20)
	end
end

function ENT:Think()
	if self.dead then return end
	if self:Health() > 0 and GetConVarNumber("ai_disabled") == 0 then
		if self.Enemy:IsValid() == false then
			self.Enemy = NULL
			self.Alerted = false
		elseif self.Enemy:Health(health) <= 0 then
			self.Enemy = NULL
			self.Alerted = false
		elseif self.Enemy == self then
			self.Enemy = NULL
			self.Alerted = false
		end

		if (self:WaterLevel() == 1) then
			local phy = self:GetPhysicsObject()
			if phy:IsValid() then
				phy:AddVelocity(self.Entity:GetAngles():Up() * 200)
			end
			if (self.Patrol and self.PatrolPoint ~= nil) then
				self.PatrolPoint = nil
			end
		elseif (self:WaterLevel() >= 2) then
			self:BreakableCopter()
		end

		if self.cooldownCheck == false then
			self.cooldownCheck = true
			if IsValid(self) then
				timer.Simple(self.shootTime, function()
					self.cooldown = true
					if IsValid(self) then
						timer.Simple(self.cooldownTime, function()
							self.cooldownCheck = false
							self.cooldown = false
						end)
					end
				end)
			end
		end
	
		local phy = self:GetPhysicsObject()
		if phy:IsValid() then
			local velocity = phy:GetVelocity()
			phy:SetAngles( Angle(20,self:GetAngles().y,0) )
			phy:SetVelocity(velocity)
			-- self:ActionTransform(self.Enemy, phy)
		end
		
		if (self.Alerted and self.AlertedCurTime < CurTime()) then
			local tr = util.TraceLine( {
				start = self:GetPos() + Vector(0, 0, -100),
				endpos = self.Enemy:GetPos() + Vector(0, 0, self.Enemy:OBBCenter().z),
				filter = function( ent ) 
					if (IsValid(ent) and ent:GetClass() ~= "npc_drg_rust_helicopter") then
						if (ent:IsVehicle()) then
							if (IsValid(ent:GetDriver())) then
								self.Enemy = ent:GetDriver()
								return true
							end
						elseif ((ent:IsPlayer() and ent:Alive()) or ent:IsNPC()) then 
							return true
						end
					end
				end
			} )

			if (tr.Entity == NULL) then
				self.Alerted = false
			elseif (tr.Entity == self.Enemy) then
				self.AlertedCurTime = CurTime() + 5
			elseif (self.AlertedCurTimeEnd == -1) then
				self.AlertedCurTimeEnd = CurTime() + 10
			elseif (self.AlertedCurTimeEnd < CurTime()) then
				self.AlertedCurTimeEnd = -1
				self.Alerted = false
			end
		elseif(not self.Alerted) then
			self:ResetEnemy()
			self:FindEnemyDan()
		end

		if (self.Enemy ~= NULL) then	
			local wantedvector = (self.Enemy:GetPos() - self:GetPos() + Vector(0,0,-80))
			local wantedangle = (self.Enemy:GetPos() - self:GetPos() + Vector(0,0,80)):Angle()
			local currentangle = Angle(20,self:GetAngles().y,0)
			local anglediff = self:GetAngleDiff(wantedangle.y,currentangle.y)
			local rocketNormalAngleShoot = (self.Enemy:GetPos() - self:GetPos()):Angle().x

			local badRocket = util.TraceLine( {
				start = self:GetPos() + Vector(0, 0, -100),
				endpos = self:GetPos() + Vector(0, 0, -700),
			} )
			
			if ( self.State == 0 and self.cooldown == false ) then
				local phy = self:GetPhysicsObject()
				if phy:IsValid() then
					if ( badRocket.Entity == NULL ) then
						if (math.abs(anglediff) < 60) then
							phy:ApplyForceCenter((wantedvector * 40))
						end
					else
						if (math.abs(anglediff) < 60) then
							phy:ApplyForceCenter((wantedvector * 40))
						end
						phy:AddVelocity(Vector(0, 0, math.random(25, 40)))
						self.PatrolPoint = nil
					end
					self:FailMove()
				end
			elseif (self.State >= 1) then
				phy:ApplyForceCenter(wantedvector * -40)
			end

			if self:GetPos():Distance(self.Enemy:GetPos()) < self.maxDistance and self.cooldown == false then
				local shoot_vector = wantedvector
				shoot_vector:Normalize()

				local bullet = {}
				bullet.Num 			= 4
				bullet.Src 			= self:GetPos() + self:GetForward()*150
				bullet.Damage 		= math.random(5, 15)
				bullet.Force		= 200
				bullet.Tracer		= 1
				bullet.Spread		= Vector( 12 / 90, 12 / 90, 0 )
				bullet.Dir 			= shoot_vector
				self:FireBullets( bullet )
				self:EmitSound("apache/fire.wav",500,100)
				
				local phy = self:GetPhysicsObject()
				if phy:IsValid() then
					if (math.random(0, 100) > 10) then
						phy:AddVelocity(self.Entity:GetAngles():Up() * math.random(5, 30))
					else
						phy:AddVelocity(self.Entity:GetAngles():Up() * -(math.random(5, 30)))
					end
				end
			elseif not self.RocketLock and math.random(0, 200) <= 10 and self.cooldown == false and badRocket.Entity == NULL and rocketNormalAngleShoot <= 100 then
				local shoot_vector = wantedvector
				shoot_vector:Normalize()
				local rocket = ents.Create("proj_dan_heli_shot_scp_sb_fg")
				if self.rocket_toggle == true then
					rocket:SetPos(self:LocalToWorld(Vector(150,40,-20)))
					self.rocket_toggle = false
				else
					rocket:SetPos(self:LocalToWorld(Vector(150,-40,-20)))
					self.rocket_toggle = true
				end
				rocket:SetAngles(shoot_vector:Angle())
				rocket:Activate()
				rocket:Spawn()
				local phy = rocket:GetPhysicsObject()
				if phy:IsValid() then
					phy:ApplyForceCenter((shoot_vector * 7500))
				end
			elseif (rocketNormalAngleShoot > 100) then
				local phy = self:GetPhysicsObject()
				if phy:IsValid() then
					if (math.random(0, 100) > 10) then
						phy:AddVelocity(self.Entity:GetAngles():Up() * math.random(5, 30))
					else
						phy:AddVelocity(self.Entity:GetAngles():Up() * -(math.random(5, 30)))
					end
				end
			end
		
			if anglediff >= -0.5 and anglediff <= 0.5 then
				local phy = self:GetPhysicsObject()
				if phy:IsValid() then
					phy:AddAngleVelocity( Vector(0, 0, 0) )
				end
			elseif anglediff > 5 then
				local phy = self:GetPhysicsObject()
				if phy:IsValid() then
					phy:AddAngleVelocity( Vector(0, 0, 5) )
				end
			elseif anglediff < -5 then
				local phy = self:GetPhysicsObject()
				if phy:IsValid() then
					phy:AddAngleVelocity( Vector(0, 0, -5) )
				end
			end
		elseif (self.Enemy == NULL and self.Patrol) then
			if (self.PatrolPoint == nil) then
				self.PatrolPoint = Vector(self:GetPos().x + math.random(-3000, 3000), self:GetPos().y + math.random(-3000, 3000), self:GetPos().z + math.random(-3000, 3000))
				-- self.PatrolPoint = Vector(1469.983887, -2788.099121, 243.759674)
				if (not util.IsInWorld(self.PatrolPoint)) then
					self.PatrolPoint = nil
					return
				end
			end
			local objects = ents.FindInSphere(self.PatrolPoint, 1000)
			if (table.HasValue(objects, self)) then
				self.PatrolPoint = nil
				return
			end
			local wantedvector = (self.PatrolPoint - self:GetPos() + Vector(0,0,-80))
			local wantedangle = (self.PatrolPoint - self:GetPos() + Vector(0,0,80)):Angle()
			local currentangle = Angle(20,self:GetAngles().y,0)
			local anglediff = self:GetAngleDiff(wantedangle.y,currentangle.y)
			local badRocket = util.TraceLine( {
				start = self:GetPos() + Vector(0, 0, -100),
				endpos = self:GetPos() + Vector(0, 0, -700),
			} )
			
			local phy = self:GetPhysicsObject()
			if phy:IsValid() then
				if ( badRocket.Entity == NULL ) then
					if (math.abs(anglediff) < 60) then
						phy:ApplyForceCenter((wantedvector * 40))
					end
				else
					if (math.abs(anglediff) < 60) then
						phy:ApplyForceCenter((wantedvector * 40))
					end
					phy:AddVelocity(Vector(0, 0, math.random(25, 40)))
				end
				self:FailMove()
			end

			if anglediff >= -0.5 and anglediff <= 0.5 then
				local phy = self:GetPhysicsObject()
				if phy:IsValid() then
					phy:AddAngleVelocity( Vector(0, 0, 0) )
				end
			elseif anglediff > 5 then
				local phy = self:GetPhysicsObject()
				if phy:IsValid() then
					phy:AddAngleVelocity( Vector(0, 0, 5) )
				end
			elseif anglediff < -5 then
				local phy = self:GetPhysicsObject()
				if phy:IsValid() then
					phy:AddAngleVelocity( Vector(0, 0, -5) )
				end
			end
		end

		if self.DestAlt + 100 > self:GetPos().z then
			local phy = self:GetPhysicsObject()
			if phy:IsValid() then
				phy:ApplyForceCenter((Vector(0.15,0,2) * 5000))
			end
		elseif self.DestAlt + 100 < self:GetPos().z then
			local phy = self:GetPhysicsObject()
			if phy:IsValid() then
				phy:ApplyForceCenter((Vector(0.15,0,-2) * 5000))
			end
		end	
	end
	
end

function ENT:ActionTransform(target, phy)
	-- Hold the desired position for the helicopter.
	if ( IsValid( phy ) ) then
		local angle = self:GetAngles();
		local warn = false;

		if ( angle.z < -80 or angle.z > 80 ) then
			phy:AddVelocity( self:GetAngles():Up() * math.random( 30, 50 ) );
			warn = true;
			if ( not self.Tilt ) then
				self.Tilt = true;
			end;
		end;

		if ( angle.x < -75 or angle.x > 60 ) then
			phy:AddVelocity( self:GetAngles():Up() * math.random( 30, 50 ) );
			warn = true;
			if ( not self.Tilt ) then
				self.Tilt = true;
			end;
		end;

		if ( not warn and self.Tilt ) then
			self.Tilt = false;
		end;

		if ( angle.x < 0 ) then
			phy:AddAngleVelocity( Vector( 0, math.random( 6, 16 ), 0 ) );
		elseif ( angle.x > 40 ) then
			phy:AddAngleVelocity( Vector( 0, math.random( -6, -16 ), 0 ) );
		elseif ( angle.x < 18 ) then
			phy:AddAngleVelocity( Vector( 0, math.random( 1, 3 ), 0 ) );
		elseif ( angle.x > 23 ) then
			phy:AddAngleVelocity( Vector( 0, math.random( -1, -3 ), 0 ) );
		end;

		if ( angle.z < -30 ) then
			phy:AddAngleVelocity( Vector( math.random( 10, 30 ), 0, 0 ) );
		elseif ( angle.z > 30 ) then
			phy:AddAngleVelocity( Vector( math.random( -10, -30 ), 0, 0 ) );
		elseif ( angle.z < -2 ) then
			phy:AddAngleVelocity( Vector( math.random( 0.5, 1.5 ), 0, 0 ) );
		elseif ( angle.z > 2 ) then
			phy:AddAngleVelocity( Vector( math.random( -0.5, -1.5 ), 0, 0 ) );
		end;
	end;
	
	-- Turning the shooting on or off, depending on the angle
	-- Normalization of the angle of attack of the helicopter
	if ( IsValid( target ) or self.Patrol ) then
		local wantedangle = Angle(0, 0, 0);
		
		if ( self.Patrol and self.PatrolPoint ~= nil ) then
			wantedangle = ( self.PatrolPoint - self:GetPos() + Vector(0, 0, 80) ):Angle();
		elseif ( IsValid( target ) ) then
			wantedangle = ( target:GetPos() - self:GetPos() + Vector(0, 0, 80) ):Angle();
		end;

		local anglediff = self:GetAngleDiff( wantedangle.y, self:GetAngles().y );
		if ( anglediff < 2 and anglediff > -20 ) then
			phy:AddAngleVelocity( Vector( 0, 0, math.random( -1, -2 ) ) );
		elseif ( anglediff > -2 and anglediff < 20 ) then
			phy:AddAngleVelocity( Vector( 0, 0, math.random( 1, 2 ) ) );
		elseif ( anglediff < 20 ) then
			phy:AddAngleVelocity( Vector( 0, 0, math.random( -5, -15 ) ) );
		elseif ( anglediff > -20 ) then
			phy:AddAngleVelocity( Vector( 0, 0, math.random( 5, 15 ) ) );
		end;
	end;
end;

function ENT:Touch( ent )
	if ent:GetClass() == "npc_grenade_rocket" then
		self:TakeDamage(200,ent)
		return
	end
	if self.State == 0 then
		ent:TakeDamage(100,self)
	end
end

function ENT:GetAngleDiff(angle1, angle2)
	local result = angle1 - angle2
	if result < -180 then
		result = result + 360
	end

	if result > 180 then
		result = result - 360
	end
	
	return result
end
   
function ENT:SelectSchedule()
if self.Enemy:IsValid() == false then
	self.Enemy = NULL
elseif self.Enemy:Health(health) <= 0 then
	self.Enemy = NULL
end

if self:Health() > 0 and self.cooldown == false then
	-- local haslos = self:HasLOS()
	local distance = 0
	local enemy_pos = 0

	if self.Enemy:IsValid() == false then
		self.Enemy = NULL
	elseif self.Enemy:Health(health) <= 0 then
		self.Enemy = NULL
	elseif self.Enemy == self then
		self.Enemy = NULL
	end

	if IsValid(self.Enemy) then
		enemy_pos = self.Enemy:GetPos()
		distance = self:GetPos():Distance(enemy_pos)
		if distance > self.maxDistance then
			self.State = 0 
		elseif distance < self.maxDistance and distance > self.minDistance then 
			self.State = 1 
		else
			self.State = 2 
		end
	end
end
end

function ENT:FindEnemyDan()
	if self.ConstOnly then
		if IsValid( self.ConstTarget ) then
			self.Enemy = self.ConstTarget
			self.Alerted = true
			return self.ConstTarget
		end
		self.Enemy = NULL
		return
	end

	local objects = ents.FindInSphere(self:GetPos(), self.FindEnemyRadius)
	local Target = NULL
	local odlDist = nil
	local isTarget = false

	for k,v in pairs(objects) do
		if (v:GetClass() ~= self:GetClass()) and v ~= self then
			if (v:IsVehicle()) then
				if (IsValid(v:GetDriver()) and v:GetDriver():IsPlayer() and v:GetDriver():Alive()) then
					self.Enemy = v:GetDriver()
					self.Alerted = true
					return true
				end
			end
			if (IsValid(v) and v:GetClass() == "npc_drg_rust_helicopter_friend") then
				self.Enemy = v
				self.Alerted = true
				return true
			end
			if (IsValid(v) and v:IsNPC() and v:Disposition(self) == D_HT) or (IsValid(v) and v:IsPlayer() and v:Alive() and GetConVarNumber("ai_ignoreplayers") == 0 and not table.HasValue(self.PlyWhiteUserGroup, v:GetUserGroup()) and not table.HasValue(self.PlyWhiteSteamID, v:SteamID())) and not table.HasValue(self.PlyWhiteTeam, v:Team()) then
				local tr = util.TraceLine( {
					start = self:GetPos() + Vector(0, 0, -100),
					endpos = v:GetPos() + Vector(0, 0, v:OBBCenter().z),
					filter = function( ent ) 
						if ( IsValid(ent) and ent:GetClass() ~= "npc_drg_rust_helicopter" and (ent:IsPlayer() and ent:Alive()) or ent:IsNPC()) then 
							self.Alerted = true
							return true
						end
					end
				} )

				if (IsValid(tr.Entity)) then
					if (odlDist == nil) then
						Target = v
						odlDist = self:GetPos():Distance(v:GetPos()) 
					elseif (self:GetPos():Distance(v:GetPos()) < odlDist) then
						Target = v
						odlDist = self:GetPos():Distance(v:GetPos()) 
					end
					isTarget = true
				end
			end
		end
	end

	if (not isTarget) then
		self.Enemy = NULL
	elseif (Target ~= NULL) then
		self.Enemy = Target
	else
		self.Enemy = NULL
	end
end

function ENT:CreateSmoke()
	local smoke = ents.Create("env_smokestack")
	smoke:SetPos(self:GetPos())
	smoke:SetAngles(self:GetAngles()+Angle(-90,0,0))
	smoke:SetKeyValue("InitialState", "1")
	smoke:SetKeyValue("WindAngle", "0 0 0")
	smoke:SetKeyValue("WindSpeed", "0")
	smoke:SetKeyValue("rendercolor", "170 170 170")
	smoke:SetKeyValue("renderamt", "170")
	smoke:SetKeyValue("SmokeMaterial", "particle/smokesprites_0001.vmt")
	smoke:SetKeyValue("BaseSpread", "2")
	smoke:SetKeyValue("SpreadSpeed", "2")
	smoke:SetKeyValue("Speed", "50")
	smoke:SetKeyValue("StartSize", "10")
	smoke:SetKeyValue("EndSize", "150")
	smoke:SetKeyValue("roll", "10")
	smoke:SetKeyValue("Rate", "15")
	smoke:SetKeyValue("JetLength", "70")
	smoke:SetKeyValue("twist", "5")
	smoke:Spawn()
	smoke:SetParent(self.Entity)
	smoke:Activate()
	return smoke
end

function ENT:KilledDan(attacker)
	hook.Run('OnNPCKilled', self, attacker, attacker)

	local isBreak = false
	local velocityZAdd = -30
	local velocityAngleZAdd = 80
	self.cooldown = true
	self.cooldownCheck = true
	self.PequodDown = true

	if not self.Smoke then
		self.Smoke = self:CreateSmoke()
	end

	if (math.random(0, 100) > 80) then
		self:BreakableCopter()
		return
	end

	local timerName = tostring(self:EntIndex()).."_copter_break_"..tostring(CurTime())
	timer.Create(timerName, 0.1, 0, function()
		if self:IsValid() then
			local phy = self:GetPhysicsObject()
			phy:AddAngleVelocity( Vector(0, 0, velocityAngleZAdd) )
			velocityAngleZAdd = velocityAngleZAdd + 0.5
			phy:SetVelocity( Vector(0, 0, velocityZAdd) )
			velocityZAdd = velocityZAdd - math.random(3, 10)

			local tr = util.TraceLine( {
				start = self:GetPos() + Vector(0, 0, -100),
				endpos = self:GetPos() + Vector(0, 0, -160),
			} )

			if (tr.Entity ~= NULL) then
				isBreak = true
			end

			if (isBreak) then
				timer.Remove(timerName)
				self:BreakableCopter()
			end
		elseif self.dead then 
			timer.Remove(timerName)
			return 
		end
	end)

	self.pequod_down_sound:Play()
	self.pequod_down_sound:PlayEx(0.5, 100)

	-- timer.Simple(6, function()
	-- 	if self.dead then return end
	-- 	if (IsValid(self)) then
	-- 		self:EmitSound("pequod_down_sound")
	-- 		-- timer.Remove(timerName)
	-- 		-- self:BreakableCopter()
	-- 	end
	-- end)
end

function ENT:BreakableCopter()
		self.dead = true

		if self.Smoke then
			self.Smoke:Remove()
			self.Smoke=nil
		end

		self:StopSounds()
		if self.warningSound:IsPlaying() then
			self.warningSound:Stop()
		end

		local ragdoll = ents.Create( "prop_physics" )
		ragdoll:SetModel( "" )
		ragdoll:SetPos( self:GetPos() )
		ragdoll:SetAngles( self:GetAngles() )
		local fire = ents.Create("env_fire_trail")
		fire:SetPos(ragdoll:GetPos() + Vector(0, 0, 50))
		fire:SetParent(ragdoll)
		ragdoll:Spawn()
		fire:Spawn()

		ragdoll:SetSkin( self:GetSkin() )
		ragdoll:SetColor( self:GetColor() )
		ragdoll:SetMaterial( self:GetMaterial() )
		if self.EnabledFire then 
			ragdoll:Ignite( math.Rand( 8, 10 ), 0 ) 
		end
		timer.Simple(self.RemoveTimeProps, function()
			if (IsValid(ragdoll)) then
				ragdoll:Remove()
			end
		end)

		local effectdata = EffectData()
		effectdata:SetStart(ragdoll:GetPos())
		effectdata:SetOrigin(ragdoll:GetPos())
		effectdata:SetScale(50)
		util.Effect("Explosion", effectdata)
		util.Effect("grenade_explosion_01", effectdata)
		util.Effect("HelicopterMegaBomb", effectdata)
		util.Effect("cball_explode", effectdata)
		timer.Simple(0.5, function()
			if (IsValid(ragdoll)) then
				effectdata:SetStart(ragdoll:GetPos())
				effectdata:SetOrigin(ragdoll:GetPos())
				util.Effect("Explosion", effectdata)
				util.Effect("grenade_explosion_01", effectdata)
				util.Effect("HelicopterMegaBomb", effectdata)
				util.Effect("cball_explode", effectdata)
				util.BlastDamage(ragdoll, ragdoll, ragdoll:GetPos(), 300, 300)
			end
		end)
		timer.Simple(0.7, function()
			if (IsValid(ragdoll)) then
				effectdata:SetStart(ragdoll:GetPos())
				effectdata:SetOrigin(ragdoll:GetPos())
				util.Effect("Explosion", effectdata)
				util.Effect("grenade_explosion_01", effectdata)
				util.Effect("HelicopterMegaBomb", effectdata)
				util.Effect("cball_explode", effectdata)
				util.BlastDamage(ragdoll, ragdoll, ragdoll:GetPos(), 300, 300)
			end
		end)
		util.BlastDamage(ragdoll, ragdoll, ragdoll:GetPos(), 300, 300)

		local ragdoll = ents.Create( "prop_physics" )
		ragdoll:SetModel( "" )
		ragdoll:SetPos( self:LocalToWorld(Vector(100,0,0)))
		ragdoll:SetAngles( self:GetAngles() )
		ragdoll:Spawn()
		ragdoll:SetSkin( self:GetSkin() )
		ragdoll:SetColor( self:GetColor() )
		ragdoll:SetMaterial( self:GetMaterial() )
		if self.EnabledFire then 
			ragdoll:Ignite( math.Rand( 8, 10 ), 0 ) 
		end
		timer.Simple(self.RemoveTimeProps, function()
			if (IsValid(ragdoll)) then
				ragdoll:Remove()
			end
		end)
		timer.Simple(1, function()
			if (IsValid(ragdoll)) then
				effectdata:SetStart(ragdoll:GetPos())
				effectdata:SetOrigin(ragdoll:GetPos())
				util.Effect("Explosion", effectdata)
				util.Effect("grenade_explosion_01", effectdata)
				util.Effect("HelicopterMegaBomb", effectdata)
				util.Effect("cball_explode", effectdata)
				util.BlastDamage(ragdoll, ragdoll, ragdoll:GetPos(), 300, 300)
			end
		end)

		local ragdollPilot = ents.Create( "prop_ragdoll" )
		ragdollPilot:SetModel( "models/player/darky_m/rust/scientist.mdl" )
		ragdollPilot:SetPos( ragdoll:GetPos() + Vector(-50, 0, 0) )
		ragdollPilot:SetCollisionGroup( COLLISION_GROUP_WORLD )
		ragdollPilot:SetColor( Color(150, 150, 150, 255) )
		ragdollPilot:Spawn()	
		if self.EnabledFire then 
			ragdollPilot:Ignite( self.RemoveTimeProps, 0 ) 
		end
		timer.Simple(self.RemoveTimeProps, function()
			if (IsValid(ragdollPilot)) then
				ragdollPilot:Remove()
			end
		end)

		local ragdollPilot = ents.Create( "prop_ragdoll" )
		ragdollPilot:SetModel( "models/player/darky_m/rust/scientist.mdl" )
		ragdollPilot:SetPos( ragdoll:GetPos() + Vector(50, 0, 0) )
		ragdollPilot:SetCollisionGroup( COLLISION_GROUP_WORLD )
		ragdollPilot:SetColor( Color(150, 150, 150, 255) )
		ragdollPilot:Spawn()	
		if self.EnabledFire then 
			ragdollPilot:Ignite( self.RemoveTimeProps, 0 ) 
		end
		timer.Simple(self.RemoveTimeProps, function()
			if (IsValid(ragdollPilot)) then
				ragdollPilot:Remove()
			end
		end)

		local ragdoll = ents.Create( "prop_physics" )
		ragdoll:SetModel( "" )
		ragdoll:SetPos( self:LocalToWorld(Vector(-100,0,0)))
		ragdoll:SetAngles( self:GetAngles() )
		ragdoll:Spawn()
		ragdoll:SetSkin( self:GetSkin() )
		ragdoll:SetColor( self:GetColor() )
		ragdoll:SetMaterial( self:GetMaterial() )
		timer.Simple(self.RemoveTimeProps, function()
			if (IsValid(ragdoll)) then
				ragdoll:Remove()
			end
		end)

		if self.EnabledFire then 
			ragdoll:Ignite( math.Rand( 8, 10 ), 0 ) 
		end

		local bar = ents.Create("env_shake")
		bar:SetPos(self:GetPos())
		bar:SetKeyValue("amplitude","8")
		bar:SetKeyValue("radius","4000")
		bar:SetKeyValue("duration","0.75")
		bar:SetKeyValue("frequency","128")
		bar:Fire( "StartShake", 0, 0 )
		timer.Simple(self.RemoveTimeProps, function()
			if (IsValid(ragdoll)) then
				bar:Remove()
			end
		end)
		
		local blargity = EffectData()
		blargity:SetStart(self:GetPos())
		blargity:SetOrigin(self:GetPos())
		blargity:SetScale(500)
		self.LoopSound:Stop()
		
		util.Effect("HelicopterMegaBomb",blargity)
		util.Effect("ThumperDust",blargity)
		self:StopSound("npc/attack_helicopter/aheli_rotor_loop1.wav")
		self:Remove()
end

function ENT:ResetEnemy()
	local enttable = ents.FindByClass("npc_*")

	for _, x in pairs(enttable) do
		if (x:GetClass() ~= self:GetClass() and x:IsNPC() and not table.HasValue(self.NPCWhiteList, x:GetClass())) then
			x:AddEntityRelationship( self, D_HT, 100 )
		elseif (x:GetClass() ~= self:GetClass() and x:IsNPC() and table.HasValue(self.NPCWhiteList, x:GetClass())) then
			x:AddEntityRelationship( self, D_LI, 100 )
		end
	end
end

function ENT:StopSounds()
	self:StopSound("pequod_down_sound")
end

function ENT:OnRemove()
	self:StopSound("npc/attack_helicopter/aheli_rotor_loop1.wav")
	self.LoopSound:Stop()
	self.warningSound:Stop()
	if self.Smoke then
		self.Smoke:Remove()
	end
	self:StopSounds()

	if self.warningSound:IsPlaying() then
		self.warningSound:Stop()
	end
end

function ENT:HasLOS()
	if self.Enemy ~= NULL then
	local tracedata = {}

	tracedata.start = self:GetPos()
	tracedata.endpos = self.Enemy:GetPos()
	tracedata.filter = self

	local trace = util.TraceLine(tracedata)
		if trace.HitWorld == false then
			return true
		else 
			return false
		end
	end
	return false
end