 ENT.Base = "base_ai"
 ENT.Type = "ai"
   
 ENT.PrintName = "Attack Helicopter"
 ENT.Author = ""
 ENT.Contact = ""
 ENT.Purpose = ""
 ENT.Instructions = ""
 ENT.Information	= ""  
 ENT.Category		= "SCP:CB"
  
 ENT.AutomaticFrameAdvance = true
   
 ENT.Spawnable = false
 ENT.AdminSpawnable = false

function ENT:SetAutomaticFrameAdvance( bUsingAnim )
  self.AutomaticFrameAdvance = bUsingAnim
end  