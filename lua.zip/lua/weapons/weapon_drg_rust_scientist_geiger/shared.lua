if not DrGBase then return end -- return if DrGBase isn't installed
SWEP.Base = "drgbase_weapon" -- DO NOT TOUCH (obviously)

-- Misc --
SWEP.PrintName = "Scientist Geiger"
SWEP.Class = "weapon_drg_rust_scientist_geiger"
SWEP.Category = "[DrGBase] Rust Weapons"
SWEP.Author = ""
SWEP.Contact = ""
SWEP.Purpose = ""
SWEP.Instructions	= ""
SWEP.Spawnable = true
SWEP.AdminOnly = false
SWEP.Slot = 2
SWEP.SlotPos = 0

-- Looks --
SWEP.HoldType = "pistol"
SWEP.ViewModelFOV	= 54
SWEP.ViewModelFlip = false
SWEP.ViewModelOffset = Vector(0, 0, 0)
SWEP.ViewModelAngle = Angle(0, 0, 0)
SWEP.UseHands = false
SWEP.ViewModel = ""
SWEP.WorldModel	= "models/darky_m/rust_weapons/w_geiger.mdl"
SWEP.CSMuzzleFlashes = false
SWEP.CSMuzzleX = false

-- Primary --

-- Shooting
SWEP.Primary.Damage = 0
SWEP.Primary.Bullets = 0
SWEP.Primary.Spread = 100
SWEP.Primary.Automatic = false
SWEP.Primary.Delay = 999999
SWEP.Primary.Recoil = 0

-- Ammo
SWEP.Primary.Ammo	= ""
SWEP.Primary.Cost = 0
SWEP.Primary.ClipSize	= 1
SWEP.Primary.DefaultClip = 1

-- Effects
SWEP.Primary.Sound = ""
SWEP.Primary.EmptySound = ""

-- DO NOT TOUCH --
AddCSLuaFile()
DrGBase.AddWeapon(SWEP)
