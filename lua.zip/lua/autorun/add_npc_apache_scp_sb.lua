sound.Add( {
	name = "pequod_pequod_down_1",
	channel = CHAN_STATIC,
	volume = 1.0,
	level = 130,
	pitch = 100,
	sound = "apache/pequod_down_1.wav"
} )

sound.Add( {
	name = "pequod_pequod_down_2",
	channel = CHAN_STATIC,
	volume = 1.0,
	level = 130,
	pitch = 100,
	sound = "apache/pequod_down_2.mp3"
} )

sound.Add( {
	name = "pequod_target_shoot",
	channel = CHAN_STATIC,
	volume = 1.0,
	level = 130,
	pitch = 100,
	sound = "apache/target_shoot.mp3"
} )

sound.Add( {
	name = "pequod_this_is_pequod_1",
	channel = CHAN_STATIC,
	volume = 1.0,
	level = 130,
	pitch = 100,
	sound = "apache/this_is_pequod_1.mp3"
} )

sound.Add( {
	name = "pequod_this_is_pequod_2",
	channel = CHAN_STATIC,
	volume = 1.0,
	level = 130,
	pitch = 100,
	sound = "apache/this_is_pequod_2.mp3"
} )

sound.Add( {
	name = "pequod_back",
	channel = CHAN_STATIC,
	volume = 1.0,
	level = 130,
	pitch = 100,
	sound = "apache/back.mp3"
} )

sound.Add( {
	name = "pequod_down_sound",
	channel = CHAN_STATIC,
	volume = 0.5,
	level = 130,
	pitch = 100,
	sound = "apache/down_sound.wav"
} )

sound.Add( {
	name = "pequod_marker",
	channel = CHAN_STATIC,
	volume = 1.0,
	level = 130,
	pitch = 100,
	sound = "apache/marker.mp3"
} )

sound.Add( {
	name = "support_helicopter_requested",
	channel = CHAN_STATIC,
	volume = 1.0,
	level = 130,
	pitch = 100,
	sound = "apache/support_helicopter_requested.mp3"
} )

local Category = "[DrGBase] Rust"
local NPC = { 	
	Name = "[W.I.P] Attack Helicopter", 
	Class = "npc_drg_rust_scientist_helicopter",
	Category = Category,
}
list.Set( "NPC", NPC.Class, NPC )

hook.Add( "PlayerSay", "HOOK.FG.Black.Helicopter.PequodFriendSupport", function( ply, text, team )
	local SupportAdd = function()
		local ok = false
		for k, v in pairs(ents.GetAll()) do
			if (v:GetClass() == "npc_apache_scp_sb_friend" and v.Enemy == NULL and not v.PlayerHelp) then
				v.PlayerHelp = true
				v.PlayerHelpID = ply
				v.PatrolPoint = ply:GetPos()
				v.HelpPosition = false
				v.PlayerHelpSoundPlay = true
				ok = true
				ply:EmitSound("apache/support_helicopter_requested.mp3")
				-- ply:SendLua([[surface.PlaySound("support_helicopter_requested")]])
				ply:SendLua([[chat.AddText(Color(0, 255, 0), "The helicopter is on the waynot ")]])
				break
			end
		end

		if (not ok) then
			ply:SendLua([[chat.AddText(Color(255, 0, 0),"At the moment, there are no free helicopters in the airnot ")]])
		end
	end

	local SimpleCommands = {
		"not helicopter support",
		"not support helicopter",
		"not pequod support",
		"/helicopter support",
		"/support helicopter",
		"/pequod support",
	}

	local find1 = {
		"нужна",
		"требуется",
		"запрашиваю",
		"need",
		"air",
		"request",
	}

	local find2 = {
		"огневая",
		"поддержка",
		"подержка",
		"fire",
		"support",
		"helicopter",
	}

	local find3 = {
		"воздуха",
		"поддержка",
		"ввертолет",
		"вертолета",
		"ввертолёт",
		"вертолёта",
		"support",
		"air",
		"request",
		"helicopter",
	}

	if (table.HasValue(SimpleCommands, text:lower())) then
		SupportAdd()
		return text
	else
		for k, f1 in pairs(find1) do
			for k, f2 in pairs(find2) do
				for k, f3 in pairs(find3) do
					local strf1 = string.find(text:lower(), f1:lower())
					local strf2 = string.find(text:lower(), f2:lower())
					local strf3 = string.find(text:lower(), f3:lower())

					if (strf1 and strf2 and strf3) then
						SupportAdd()
						return text
					end
				end
			end
		end
	end
end )